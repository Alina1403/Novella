package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class MyGdxGame implements Screen {
	final Drop game;
	TextureRegion backgroundTexture;
	Music fonMusic; //музыка для фона
	OrthographicCamera camera;

	public MyGdxGame(final Drop gam) {
		this.game = gam;

		// загрузка звукового фона для игры
		fonMusic = Gdx.audio.newMusic(Gdx.files.internal("fon.mp3"));
		fonMusic.setLooping(true);

		//устанавливаем фон
		backgroundTexture = new TextureRegion(new Texture("room.png"), 0, 0, 800, 480);

		// создает камеру
		camera = new OrthographicCamera();
		camera.setToOrtho(false, 800, 480);
	}
	@Override
	public void render(float delta) {

		// сообщает камере, что нужно обновить матрицы.
		camera.update();
		game.batch.begin();

		//отрисовываем изображение
		game.batch.draw(backgroundTexture, 0, 0);
		game.batch.draw(backgroundTexture, 0, Gdx.graphics.getHeight());

		//отрисовываем текст
		game.font.draw(game.batch, "Время 7:00", 350, 450);
		game.font.draw(game.batch, "Ваши занятия начинаются в 9:50. Ваши действия:", 200, 410);
		game.font.draw(game.batch, "Встать сейчас", 500, 100);
		game.font.draw(game.batch, "Поспать еще", 100, 100);

		if (Gdx.input.isKeyPressed(Input.Keys.LEFT))
			game.setScreen(new Room(game));
		dispose();
		if (Gdx.input.isKeyPressed(Input.Keys.RIGHT))
			game.setScreen(new Kitchen(game));
		dispose();

		// сообщаем SpriteBatch о системе координат
		// визуализации указанных для камеры.
		game.batch.setProjectionMatrix(camera.combined);
		game.batch.end();

	}
	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void show() {
		// воспроизведение фоновой музыки, когда отображается экран
		fonMusic.play();
	}

	@Override
	public void hide() {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void dispose() {

	}

}