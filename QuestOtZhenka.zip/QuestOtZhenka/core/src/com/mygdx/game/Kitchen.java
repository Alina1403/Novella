package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector3;

public class Kitchen implements Screen {
    final Drop game;

    TextureRegion backgroundTexture;
    Music fonMusic; //музыка для фона
    OrthographicCamera camera;

    public Kitchen(final Drop gam) {
        this.game = gam;

        // загрузка звукового фона для игры
        fonMusic = Gdx.audio.newMusic(Gdx.files.internal("fon.mp3"));
        fonMusic.setLooping(true);

        //устанавливаем фон
        backgroundTexture = new TextureRegion(new Texture("kitchen.png"), 0, 0, 800, 480);

        // создает камеру
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);
    }
    @Override

    public void render(float delta) {

        // сообщает камере, что нужно обновить матрицы.
        camera.update();
        game.batch.begin();

        //отрисовываем изображение
        game.batch.draw(backgroundTexture, 0, 0);
        game.batch.draw(backgroundTexture, 0, Gdx.graphics.getHeight());

        //отрисовываем текст
        game.font.draw(game.batch, "Вы позавтракали и уснули за столом", 250, 450);
        game.font.draw(game.batch, "Время 8:55. Ваши действия:", 270, 410);
        game.font.draw(game.batch, "Побежать на автобус", 500, 100);
        game.font.draw(game.batch, "Пойти пешком", 100, 100);

        // сообщаем SpriteBatch о системе координат
        // визуализации указанных для камеры.
        game.batch.setProjectionMatrix(camera.combined);
        game.batch.end();

        // обработка пользовательского ввода
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT))
            game.setScreen(new Bus(game));
        dispose();
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT))
            game.setScreen(new Street(game));
        dispose();

    }
    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {

    }

    @Override
    public void hide() {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void dispose() {

    }

}

