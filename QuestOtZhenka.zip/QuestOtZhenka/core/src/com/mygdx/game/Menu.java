package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Menu implements Screen {

    TextureRegion backgroundTexture;
    final Drop game;
    OrthographicCamera camera;

    public Menu(final Drop gam) {
        game = gam;
        camera = new OrthographicCamera();
        camera.setToOrtho(false, 800, 480);// гранийы камеры
        backgroundTexture = new TextureRegion(new Texture("bckground.png"), 0, 0, 800, 480); // устанавливаем фон
    }

    @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        camera.update();
        game.batch.setProjectionMatrix(camera.combined);

        //отрисовываем фон и текст
        game.batch.begin();
        game.batch.draw(backgroundTexture, 0, 0);
        game.batch.draw(backgroundTexture, 0, Gdx.graphics.getHeight());
        game.font.draw(game.batch, "Добро пожаловать в квест от  Женька!", 200, 240);
        game.font.draw(game.batch, "Ваша задача выбрать правильный путь, чтобы Женек смог попасть на занятия!", 50, 200);
        game.font.draw(game.batch, "Нажмите на клавишу с стрелкой направо.", 200, 150);
        game.batch.end();

        //обработка пользовательского ввода с помощью стрелок на клавиатуре
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT))
            game.setScreen(new Rukovodstvo(game));
        dispose();
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }

}